﻿namespace PhotoShare.Data
{
    public class ServerConfig
    {
        public static string ConnectionString => @"Server=(localdb)\MSSQLLocalDB;Database=PhotoShare;Integrated Security=True;";
    }
}
