namespace FastFood.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=DESKTOP-UQV52NH\SQLEXPRESS;Database=FastFood;Trusted_Connection=True";
	}
}