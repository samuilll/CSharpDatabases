﻿namespace Instagraph.DataProcessor.Dtos
{
    internal class Required
    {
    }
}