﻿namespace Instagraph.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => @"Server=(LocalDb)\MSSQLLocalDB;Database=Instagraph;Integrated Security=True;";
    }
}
