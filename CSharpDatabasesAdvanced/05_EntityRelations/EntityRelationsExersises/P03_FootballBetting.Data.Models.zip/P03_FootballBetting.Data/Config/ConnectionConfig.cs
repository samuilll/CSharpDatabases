﻿namespace P01_StudentSystem.Data
{
    public class ConnectionConfig
    {
        public const string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=Football;Integrated Security = True";

    }
}