﻿namespace 	P03_SalesDatabase.Data
{
    internal class Configuration
    {
        public  const string ConnectionbString =
                        @"Server=(localdb)\MSSQLLocalDB;Database=Sales;Integrated Security = True";

    }
}