﻿namespace P01_HospitalDatabase.Data
{
    internal class Configuration
    {
        public  const string ConnectionbString =
                        @"Server=(localdb)\MSSQLLocalDB;Database=Hospital;Integrated Security = True";

    }
}